/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.detran.bd;

/**
 *
 * @author 12723129948
 */
public class Exame {
    
    private int id;
    private Pessoa pessoa;
    private int tipo;
    private int status;

    public Exame(int id, Pessoa pessoa, int tipo) {
        this.id = id;
        this.pessoa = pessoa;
        this.tipo = tipo;
        this.status = 0;
    }

    public int getId() {
        return id;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public Pessoa getPessoa() {
        return pessoa;
    }

    public int getTipo() {
        return tipo;
    }
    
    
    
}
