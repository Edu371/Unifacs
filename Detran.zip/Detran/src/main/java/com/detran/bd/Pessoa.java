/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.detran.bd;

import java.time.LocalDate;
import java.util.ArrayList;

/**
 *
 * @author 12723129948
 */
public class Pessoa {
    
    private String nome;
    private LocalDate nascimento;
    private String endereco;
    private String rg;
    private String cpf;
    private String telefone;
    private String email;
    private String senha;
    private int privilegio;
    private ArrayList<Exame> exames;

    public Pessoa(String nome, LocalDate nascimento, String rg, String cpf, String senha, int privilegio) {
        this.nome = nome;
        this.nascimento = nascimento;
        this.rg = rg;
        this.cpf = cpf;
        this.senha = senha;
        this.privilegio = privilegio;
        this.exames = new ArrayList<>();
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getNome() {
        return nome;
    }

    public LocalDate getNascimento() {
        return nascimento;
    }

    public String getRg() {
        return rg;
    }

    public String getCpf() {
        return cpf;
    }

    public int getPrivilegio() {
        return privilegio;
    }

    public ArrayList<Exame> getExames() {
        return exames;
    }
    
    public void addExame(Exame exame) {
        this.exames.add(exame);
    }
    
}
