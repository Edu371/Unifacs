/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.detran.bd;

import java.util.HashMap;

/**
 *
 * @author 12723129948
 */
public class Banco {
    
    private HashMap pessoas;
    private HashMap medicos;
    private HashMap exames;
    private int exame_count;

    public Banco() {
        this.pessoas = new HashMap<String, Pessoa>();
        this.medicos = new HashMap<String, Medico>();
        this.exames = new HashMap<String, Exame>();
    }
    
    public boolean addPessoa(Pessoa pessoa) {
        if (!pessoas.containsKey(pessoa.getCpf())) {
            pessoas.put(pessoa.getCpf(), pessoa);
            return true;
        } else {
            return false;
        }
    }
    
    public Pessoa getPessoa(String cpf) {
        if (pessoas.containsKey(cpf)) {
            return (Pessoa)pessoas.get(cpf);
        }
        return null;
    }
    
    public boolean addMedico(Medico medico) {
        if (!medicos.containsKey(medico.getCpf())) {
            medicos.put(medico.getCpf(), medico);
            return true;
        } else {
            return false;
        }
    }
    
    public Medico getMedico(String cpf) {
        if (medicos.containsKey(cpf)) {
            return (Medico)medicos.get(cpf);
        }
        return null;
    }
    
    public int addExame(Pessoa pessoa, int tipo) {
        exames.put(exame_count, new Exame(exame_count, pessoa, tipo));
        pessoa.addExame((Exame)exames.get(exame_count));
        exame_count++;
        return exame_count - 1;
    }
    
}
