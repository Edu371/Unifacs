/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.detran.main;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import com.detran.bd.Pessoa;
import com.detran.bd.Banco;

import java.security.NoSuchAlgorithmException;  
import java.security.MessageDigest; 

import java.util.Scanner;


/**
 *
 * @author 12723129948
 */
public class App {
    
    static Banco banco = new Banco();
    
    public static String hash(String senha) {  
        String hashSenha = null;  
        try   
        {  
            /* MessageDigest instance for SHA-256. */  
            MessageDigest m = MessageDigest.getInstance("SHA-256");  
              
            /* Add plain-text password bytes to digest using MD5 update() method. */  
            m.update(senha.getBytes());  
              
            /* Convert the hash value into bytes */   
            byte[] bytes = m.digest();  
              
            /* The bytes array has bytes in decimal form. Converting it into hexadecimal format. */  
            StringBuilder s = new StringBuilder();  
            for(int i=0; i< bytes.length ;i++)  
            {  
                s.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));  
            }  
              
            /* Complete hashed password in hexadecimal format */  
            hashSenha = s.toString();  
        }   
        catch (NoSuchAlgorithmException e)   
        {  
            e.printStackTrace();  
        }  
        
        return hashSenha;
    }
    
    public static boolean isInteger(String numero) {
        try {
            Long.valueOf(numero);
            return true;
        } catch (NumberFormatException nfe) {
            return false;
        }
    }
    
    public static void singUp(String nome, String nascimento, String rg, String cpf, String senha) {
        rg = rg.replace("-", "").replace(".", "");
        cpf = cpf.replace("-", "").replace(".", "");
        
        if (!((rg.length() == 10) && isInteger(rg))) {
            System.out.println("Rg Inválido");
            return;
        }
        
        if (!((cpf.length() == 11) && isInteger(cpf))) {
            System.out.println("Cpf Inválido");
            return;
        }
        
        nascimento = nascimento.replace("/", "");
        LocalDate date;
        try {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
            date = LocalDate.parse(nascimento, formatter);
        } catch (DateTimeParseException e) {
            System.out.println("Data Inválida");
            return;
        }
        
        banco.addPessoa(new Pessoa(nome, date, rg, cpf, hash(senha), 0));
        System.out.println("Registrado com sucesso");
        
    }
    
    public static Pessoa login(String cpf, String senha) {
        cpf = cpf.replace("-", "").replace(".", "");
        Pessoa pessoa = banco.getPessoa(cpf);
        if (pessoa == null) {
            System.out.println("Usuário Inexistente");
            return null;
        }
        
        if (pessoa.getSenha().equals(hash(senha))) {
            return pessoa;
        } else {
            System.out.println("Senha Incorreta");
            return null;
        }
        
    }
    
    public static boolean checkAge(LocalDate a) {
        
        LocalDate b = LocalDate.now();
        
        int diff = b.getYear() - a.getYear();
        if (a.getMonthValue() > b.getMonthValue() || 
            (a.getMonthValue() == b.getMonthValue() && a.getDayOfMonth() > b.getDayOfMonth())) {
            diff--;
        }
        
        return diff >= 18;

    }
    
    public static void main(String[] args) {
        Pessoa adm = new Pessoa("Admin", LocalDate.of(0, 1, 1), "0000000000", "00000000000", hash("admin"), 3);
        
        banco.addPessoa(adm);
        
        
        Scanner scanner = new Scanner(System.in);
        String input;
        boolean running = true;
        Pessoa user = null;
        
        while (running) {
            if (user == null) {
                System.out.println("1 - Logar");
                System.out.println("2 - Registrar-se");
                System.out.println("3 - Fechar Sistema");

                input = scanner.nextLine();

                switch (input) {
                    case "1" -> {
                        System.out.print("Cpf: ");
                        String cpf = scanner.nextLine();
                        System.out.print("Senha: ");
                        String senha = scanner.nextLine();
                        user = login(cpf, senha);
                        if (user != null) {
                            System.out.println("Logado Com Sucesso");
                        }
                    }
                    case "2" -> {
                        System.out.print("Nome: ");
                        String nome = scanner.nextLine();
                        System.out.print("Data de Nascimento(AAAAMMDD): ");
                        String nascimento = scanner.nextLine();
                        System.out.print("RG: ");
                        String rg = scanner.nextLine();
                        System.out.print("Cpf: ");
                        String cpf = scanner.nextLine();
                        System.out.print("Senha: ");
                        String senha = scanner.nextLine();
                        singUp(nome, nascimento, rg, cpf, senha);
                    }
                    case "3" -> {
                        System.out.println("Encerrando Sistema");
                        running = false;
                    }
                }
            } else {
                System.out.println("User: " + user.getNome());
                System.out.println("1 - Solicitar Boleto");
                scanner.nextLine();
            }
            
        }
        
    }
}
