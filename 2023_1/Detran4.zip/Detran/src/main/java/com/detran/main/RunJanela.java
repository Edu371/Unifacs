/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.detran.main;

/**
 *
 * @author Edu
 */
public class RunJanela {
    
    public static void main(String[] args) {
        App app = new App();
        Janela janela = new Janela(app);
        janela.setVisible(true);
    }
}
