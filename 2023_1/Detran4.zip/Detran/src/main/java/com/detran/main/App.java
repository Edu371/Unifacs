/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.detran.main;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import com.detran.bd.*;

import java.security.NoSuchAlgorithmException;  
import java.security.MessageDigest; 


/**
 *
 * @author 12723129948
 */
public class App {
    
    private Banco banco;
    public Pessoa user;
    private double preco_nova = 577.36;
    private double preco_renovar = 210.37;
    private double preco_2via = 116.50;
    
    public String hash(String senha) {  
        String hashSenha = null;  
        try   
        {  
            /* MessageDigest instance for SHA-256. */  
            MessageDigest m = MessageDigest.getInstance("SHA-256");  
              
            /* Add plain-text password bytes to digest using MD5 update() method. */  
            m.update(senha.getBytes());  
              
            /* Convert the hash value into bytes */   
            byte[] bytes = m.digest();  
              
            /* The bytes array has bytes in decimal form. Converting it into hexadecimal format. */  
            StringBuilder s = new StringBuilder();  
            for(int i=0; i< bytes.length ;i++)  
            {  
                s.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));  
            }  
              
            /* Complete hashed password in hexadecimal format */  
            hashSenha = s.toString();  
        }   
        catch (NoSuchAlgorithmException e)   
        {  
            e.printStackTrace();  
        }  
        
        return hashSenha;
    }
    
    public boolean isInteger(String numero) {
        try {
            Long.valueOf(numero);
            return true;
        } catch (NumberFormatException nfe) {
            return false;
        }
    }
    
    public String singUp(String nome, String nascimento, String rg, String cpf, String senha) {
        rg = rg.replace("-", "").replace(".", "");
        cpf = cpf.replace("-", "").replace(".", "");
        
        if (!((rg.length() == 10) && isInteger(rg))) {
            return "Rg Inválido";
        }
        
        if (!((cpf.length() == 11) && isInteger(cpf))) {
            return "Cpf Inválido";
        }
        
        nascimento = nascimento.replace("/", "");
        LocalDate date;
        try {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("ddMMyyyy");
            date = LocalDate.parse(nascimento, formatter);
        } catch (DateTimeParseException e) {
            return "Data Inválida";
        }
        
        if (banco.addPessoa(new Pessoa(nome, date, rg, cpf, hash(senha), 0))) {
            user = banco.getPessoa(cpf);
            return "Sucesso";
        }
        
        return "Usuário Já Existente";
    }
    
    public boolean login(String cpf, String senha, boolean tipo) {
        cpf = cpf.replace("-", "").replace(".", "").replace(" ", "");
        Pessoa pessoa = null;
        if (!tipo) {
            if (banco.getMedico(cpf) != null) {pessoa = banco.getMedico(cpf);}
        } else {
            pessoa = banco.getPessoa(cpf);
        }
        if (pessoa == null) {
            System.out.println("Usuário Inexistente");
            return false;
        }
        
        if (pessoa.getSenha().equals(hash(senha))) {
            user = pessoa;
            return true;
        } else {
            System.out.println("Senha Incorreta");
            return false;
        }
        
    }
    
    public boolean checkAge(LocalDate a) {
        
        LocalDate b = LocalDate.now();
        
        int diff = b.getYear() - a.getYear();
        if (a.getMonthValue() > b.getMonthValue() || 
            (a.getMonthValue() == b.getMonthValue() && a.getDayOfMonth() > b.getDayOfMonth())) {
            diff--;
        }
        
        return diff >= 18;

    }
    
    public String checkStatus() {
        String[] status = {"Aguardando Ínicio do Processo", "Aguardando Pagamento do Boleto", 
        "Aguardado Agendamento de Exames", "Aguardando Relização de Exame Psicológico",
        "Aguardando Relização de Exame Médico", "Aguardando Relização de Exame Teórico",
        "Aguardando Relização de Exame Prático", "Em Dia", "Habilitação Vencida"};
        return status[user.getStatus()];
    }
    
    public void gerarBoleto(int tipo) {
        double[] precos = {preco_nova, preco_2via, preco_renovar};
        if (user.getBoleto() == null) {
            user.setBoleto(new Boleto(precos[tipo]));
            if (user.getStatus() == 0) {user.setStatus(1);}
        }
    }
    
    public void boletoPago(Pessoa pessoa) {
        pessoa.setBoleto(null);
        if (pessoa.getStatus() == 1) {
            pessoa.setStatus(2);
        }
    }
    
    public void lancarResultado(int index, boolean aprovado) {
        Exame exame = user.getExame(index);
        int status = exame.getStatus();
        if (aprovado) {
            exame.setStatus(1);
        } else {
            if (status == 0) {exame.setStatus(2);}
            if (status == 2) {exame.setStatus(3);}
        }
    
    }
    
    public App() {
        
        this.banco = new Banco();
        
        Pessoa adm = new Pessoa("Admin", LocalDate.of(0, 1, 1), "0000000000", "00000000000", hash("admin"), 0);
        
        banco.addPessoa(adm);
        banco.addMedico(new Medico("Mede-cú", LocalDate.of(0, 1, 1), "0000000000", "00000000001", hash("admin")));
        
    }
}
