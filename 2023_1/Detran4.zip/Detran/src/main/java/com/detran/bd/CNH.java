/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.detran.bd;

import java.time.LocalDate;

/**
 *
 * @author Edu
 */
public class CNH {
    
    private Pessoa pessoa;
    private LocalDate emissao;
    private LocalDate emissao_original;
    private LocalDate vencimento;
    private String registro;

    public CNH(Pessoa pessoa, LocalDate emissao, LocalDate vencimento, String registro) {
        this.pessoa = pessoa;
        this.emissao = emissao;
        this.emissao_original = emissao;
        this.vencimento = vencimento;
        this.registro = registro;
    }
    
    public void renovar(LocalDate emissao, LocalDate vencimento) {
        this.emissao = emissao;
        this.vencimento = vencimento;
    }

    public Pessoa getPessoa() {
        return pessoa;
    }

    public LocalDate getEmissao() {
        return emissao;
    }

    public LocalDate getEmissao_original() {
        return emissao_original;
    }

    public LocalDate getVencimento() {
        return vencimento;
    }

    public String getRegistro() {
        return registro;
    }
    
    
    
}
