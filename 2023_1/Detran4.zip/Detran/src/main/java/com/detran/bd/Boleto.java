/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.detran.bd;
import java.time.LocalDate;
import java.util.Random;

/**
 *
 * @author Edu
 */
public class Boleto {
    
    private final LocalDate inicio = LocalDate.of(1997,10,7);
    
    private int prazo = 30;
    private LocalDate emicao;
    private LocalDate vencimento;
    private double valor;
    private String numero;
    
    public Boleto(double valor) {
        this.emicao = LocalDate.now();
        this.vencimento = this.emicao.plusDays(prazo);
        this.valor = valor;
        numero = "00090." + String.format("%04d", new Random().nextInt(1000)) + "1 23456.789012 34567.89012 0 " 
                + inicio.datesUntil(vencimento).count()
                + String.format("%010d", (int)(valor*100));
    }

    public LocalDate getEmicao() {
        return emicao;
    }

    public LocalDate getVencimento() {
        return vencimento;
    }

    public double getValor() {
        return valor;
    }

    public String getNumero() {
        return numero;
    }
    
    
    
}
