/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.detran.bd;

/**
 *
 * @author 12723129948
 */
public class Exame {
    
    private int id;
    private Pessoa pessoa;
    private Medico medico;
    private int tipo;
    private int status;
    /* status 
        0 = Aguardando Resultado
        1 = Aprovado
        2 = Reprovado
        3 = Reprovado 2ª vez
    */

    public Exame(int id, Pessoa pessoa, int tipo, Medico medico) {
        this.id = id;
        this.pessoa = pessoa;
        this.tipo = tipo;
        this.status = 0;
        this.medico = medico;
    }

    public int getId() {
        return id;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public Pessoa getPessoa() {
        return pessoa;
    }

    public int getTipo() {
        return tipo;
    }
    
    public Medico getMedico() {
        return medico;
    }
    
}
