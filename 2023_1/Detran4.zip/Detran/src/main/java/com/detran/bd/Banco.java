/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.detran.bd;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Random;

/**
 *
 * @author 12723129948
 */
public class Banco {
    
    private HashMap pessoas;
    private HashMap medicos;
    private HashMap exames;
    private HashMap cnhs;
    private int exame_count;
    private int cnh_count;

    public Banco() {
        this.pessoas = new HashMap<String, Pessoa>();
        this.medicos = new HashMap<String, Medico>();
        this.exames = new HashMap<String, Exame>();
        this.cnhs = new HashMap<String, CNH>();
    }
    
    public boolean addPessoa(Pessoa pessoa) {
        if (!pessoas.containsKey(pessoa.getCpf())) {
            pessoas.put(pessoa.getCpf(), pessoa);
            return true;
        } else {
            return false;
        }
    }
    
    public Pessoa getPessoa(String cpf) {
        if (pessoas.containsKey(cpf)) {
            return (Pessoa)pessoas.get(cpf);
        }
        return null;
    }
    
    public boolean addMedico(Medico medico) {
        if (!medicos.containsKey(medico.getCpf())) {
            medicos.put(medico.getCpf(), medico);
            return true;
        } else {
            return false;
        }
    }
    
    public Medico getMedico(String cpf) {
        if (medicos.containsKey(cpf)) {
            return (Medico)medicos.get(cpf);
        }
        return null;
    }
    
    public int addExame(Pessoa pessoa, int tipo) {
        
        // Atribui Exame a médico aleatório
        int med = new Random().nextInt(medicos.size());
        Medico medico = (Medico)medicos.get(medicos.keySet().toArray()[med]);
        
        Exame exame = new Exame(exame_count, pessoa, tipo, medico);
        exames.put(exame_count, exame);
        pessoa.addExame(exame, tipo);
        exame_count++;
        medico.addExame(exame, tipo);
        
        return exame_count - 1;
    }
    
    public Exame getExame(int id) {
        return (Exame)exames.get(id);
    }
    
    public void addCNH(Pessoa pessoa, LocalDate emissao, LocalDate vencimento) {
        if (pessoa.getCnh() == null) {
            CNH cnh = new CNH(pessoa, emissao, vencimento, String.valueOf(cnh_count));
            cnhs.put(cnh_count, cnh);
            pessoa.setCnh(cnh);
            cnh_count++;
        }
    }
    
    public CNH getCNH(int registro) {
        return (CNH)cnhs.get(registro);
    }
    
}
