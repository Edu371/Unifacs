/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.detran.main.teste;

/**
 *
 * @author Edu
 */
public class Teste {
    
    public void print() {
        System.out.println(this);
    }
    
    public Teste() {
        System.out.println("A");
        NewJFrame frame = new NewJFrame(this);
        frame.setVisible(true);
        System.out.println("B");
    }
    
}
