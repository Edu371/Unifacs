/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.detran.bd;

import java.time.LocalDate;

/**
 *
 * @author 12723129948
 */
public class Medico extends Pessoa {

    public Medico(String nome, LocalDate nascimento, String rg, String cpf, String senha) {
        super(nome, nascimento, rg, cpf, senha, 1);
    }
    
    
    
}
